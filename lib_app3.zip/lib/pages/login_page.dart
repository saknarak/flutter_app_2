import 'package:flutter/material.dart';

class LoginPage extends StatelessWidget {
  LoginPage({super.key});

  final userCtrl = TextEditingController(text: '');
  final userFocus = FocusNode();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding:
            const EdgeInsets.only(top: 40, bottom: 40, left: 20, right: 20),
        child: Column(
          children: [
            Image.asset('logo/logo.png'),
            Padding(
              padding: const EdgeInsets.only(bottom: 20),
              child: TextField(
                controller: userCtrl,
                focusNode: userFocus,
                decoration: InputDecoration(
                  label: Text('ชื่อผู้ใช้'),
                  icon: Icon(Icons.account_box),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(bottom: 20),
              child: TextField(
                obscureText: true,
                decoration: InputDecoration(
                  label: Text('รหัสผ่าน'),
                ),
              ),
            ),
            Row(
              children: [
                OutlinedButton(
                  onPressed: () {},
                  child: Text('ลงทะเบียน'),
                ),
                FilledButton(
                  onPressed: onLogin,
                  child: Text('เข้าสู่ระบบ'),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }

  onLogin() {
    if (userCtrl.text == '') {
      // focus
      userFocus.requestFocus();
      return;
    }

    // call rest api
    print('user=${userCtrl.text}');
  }
}
