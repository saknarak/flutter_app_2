import 'package:flutter/material.dart';

class StudentPage extends StatelessWidget {
  const StudentPage({super.key});

  @override
  Widget build(BuildContext context) {
    final students = [];
    for (int i = 0; i < 100; i++) {
      students.add({
        'code': '6300${i + 1}',
        'name': 'Student ${i + 1}',
      });
    }
    return Scaffold(
      appBar: AppBar(
        leading: Icon(Icons.abc),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('รายชื่อนักเรียน'),
            Text(
              'ปวช. 1/3',
              style: TextStyle(
                fontSize: 12,
              ),
            ),
          ],
        ),
      ),
      body: ListView.builder(
        itemCount: students.length,
        itemBuilder: (BuildContext context, int index) {
          print('index=$index');
          return ListTile(
            dense: true,
            leading: Text('X'),
            title: Text(students[index]['name']),
            subtitle: Text(students[index]['code']),
            trailing: Text('Y'),
          );
        },
      ),
    );
  }
}
