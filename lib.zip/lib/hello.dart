// void main() {
//   // print('3 + 5 = ${add2(3, d: 10, c: 10)}');
// }

// int add(int a, [int b = 10, int c = 10]) {
//   return a + b + c;
// }

// int add2(int a, {int title = 10, required int c, int d = 10}) {
//   return a + b + c + d;
// }
