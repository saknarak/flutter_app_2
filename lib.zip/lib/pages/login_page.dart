import 'package:flutter/material.dart';

class LoginPage extends StatelessWidget {
  LoginPage({super.key});

  final userCtrl = TextEditingController(text: '');
  final userFocus = FocusNode();

  @override
  Widget build(BuildContext context) {
    int i = 500;
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.only(
          top: 50,
          bottom: 50,
          left: 20,
          right: 20,
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Image.asset('logo/logo.png'),
            Padding(
              padding: const EdgeInsets.only(bottom: 16),
              child: TextField(
                controller: userCtrl,
                focusNode: userFocus,
                decoration: InputDecoration(
                  label: Text('ชื่อผู้ใช้'),
                  icon: const Icon(Icons.face),
                ),
              ),
            ),
            const Padding(
              padding: EdgeInsets.only(bottom: 16),
              child: TextField(
                obscureText: true,
                decoration: InputDecoration(
                  label: Text('รหัสผ่าน'),
                ),
              ),
            ),
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                SizedBox(
                  width: 160,
                  child: OutlinedButton(
                    onPressed: () {},
                    child: const Row(
                      children: [
                        Icon(Icons.face),
                        Text('ลงทะเบียน'),
                      ],
                    ),
                  ),
                ),
                const SizedBox(
                  width: 20,
                ),
                SizedBox(
                  width: 120,
                  child: FilledButton(
                    onPressed: doLogin,
                    child: const Text('เข้าสู่ระบบ'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  doLogin() {
    print('user=${userCtrl.text}');
    if (userCtrl.text == '') {
      userFocus.requestFocus();
      return;
    }
    // if (passCtrl.text == '') {
    //   passFocus.requestFocus();
    // }
    userCtrl.text = '';
  }
}
